import contextlib
import importlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

APP_NAME = "SNA Video Downloader"
APP_RUNTIME_DIRNAME = "SNA-Downloader"
WINDOWS_FFMPEG_URL = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
URL_IN_TEXT_RE = re.compile(r"https?://[^\s<>\"{}|\\^`\[\]]+", re.I)
DOUYIN_VIDEO_RE = re.compile(r"douyin\.com/video/(?P<id>\d+)", re.I)
DOUYIN_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
)
DOUYIN_BROWSER_FALLBACKS = ("edge", "firefox", "opera", "chrome", "brave")
BROWSER_PROCESS_NAMES = {
    "chrome": "chrome.exe",
    "edge": "msedge.exe",
    "firefox": "firefox.exe",
    "brave": "brave.exe",
    "opera": "opera.exe",
}
DOUYIN_COOKIES_FILENAME = "douyin_cookies.txt"
SETTINGS_FILENAME = "settings.json"


class _YtdlQuietLogger:
    def debug(self, msg):
        pass

    def info(self, msg):
        pass

    def warning(self, msg):
        pass

    def error(self, msg):
        pass


def is_browser_running(browser: str) -> bool:
    proc_name = BROWSER_PROCESS_NAMES.get(browser.strip().lower())
    if not proc_name or not sys.platform.startswith("win"):
        return False
    try:
        out = subprocess.check_output(
            ["tasklist", "/FI", f"IMAGENAME eq {proc_name}", "/NH"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return proc_name.lower() in out.lower()
    except Exception:
        return False


def is_recoverable_douyin_error(err: str) -> bool:
    err = err.lower()
    return any(
        key in err
        for key in (
            "cookie",
            "fresh cookies",
            "dpapi",
            "decrypt",
            "could not copy",
            "cookie database",
            "failed to decrypt",
        )
    )


def douyin_cookies_file() -> Path | None:
    path = app_runtime_dir() / DOUYIN_COOKIES_FILENAME
    if path.exists() and path.stat().st_size > 0:
        return path
    return None


def settings_file() -> Path:
    return app_runtime_dir() / SETTINGS_FILENAME


def default_save_folder() -> str:
    downloads = Path.home() / "Downloads"
    preferred = downloads / "My Videos"
    if preferred.exists():
        return str(preferred)
    return str(downloads)


def load_settings_dict() -> dict:
    path = settings_file()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_settings_dict(data: dict) -> None:
    path = settings_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")



def is_frozen_app() -> bool:
    return bool(getattr(sys, "frozen", False))


def app_root_dir() -> Path:
    if is_frozen_app():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def app_runtime_dir() -> Path:
    if is_frozen_app():
        base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or app_root_dir())
        return base / APP_RUNTIME_DIRNAME
    return app_root_dir() / ".runtime"


def runtime_message(log_fn, message: str) -> None:
    if callable(log_fn):
        try:
            log_fn(message)
            return
        except Exception:
            pass
    print(message)


def ensure_pip_package(import_name: str, pip_name: str | None = None) -> bool:
    pip_name = pip_name or import_name
    try:
        importlib.import_module(import_name)
        return True
    except ImportError:
        if is_frozen_app():
            return False
        install_cmd = [sys.executable, "-m", "pip", "install", "--upgrade", pip_name]
        try:
            subprocess.check_call(
                install_cmd,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            importlib.import_module(import_name)
            return True
        except Exception:
            return False


if not ensure_pip_package("ttkbootstrap", "ttkbootstrap"):
    print("Missing dependency: ttkbootstrap. Install with: pip install ttkbootstrap")
    sys.exit(1)
if not ensure_pip_package("yt_dlp", "yt-dlp"):
    print("Missing dependency: yt-dlp. Install with: pip install yt-dlp")
    sys.exit(1)

import tkinter as tk
from tkinter import filedialog

import ttkbootstrap as tb
import yt_dlp
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox


def write_netscape_cookies(cookies: list[dict], path: Path) -> None:
    lines = [
        "# Netscape HTTP Cookie File",
        "# https://curl.haxx.se/rfc/cookie_spec.html",
        "# This is a generated file! Do not edit.",
        "",
    ]
    for cookie in cookies:
        domain = cookie.get("domain") or ""
        name = cookie.get("name") or ""
        if not domain or not name:
            continue
        include_sub = "TRUE" if domain.startswith(".") else "FALSE"
        cookie_path = cookie.get("path") or "/"
        secure = "TRUE" if cookie.get("secure") else "FALSE"
        expires = int(cookie.get("expires") or 0)
        value = cookie.get("value") or ""
        lines.append(f"{domain}\t{include_sub}\t{cookie_path}\t{secure}\t{expires}\t{name}\t{value}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def auto_fetch_douyin_cookies(log_fn=None, sample_url: str | None = None) -> Path | None:
    if not ensure_pip_package("playwright", "playwright"):
        runtime_message(log_fn, "[Douyin] Could not install playwright.")
        return None

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        runtime_message(log_fn, "[Douyin] Playwright is not available.")
        return None

    dest = app_runtime_dir() / DOUYIN_COOKIES_FILENAME
    app_runtime_dir().mkdir(parents=True, exist_ok=True)

    def install_chromium() -> None:
        runtime_message(log_fn, "[Douyin] Installing Chromium (first time only)...")
        subprocess.check_call(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )

    for attempt in range(2):
        try:
            runtime_message(log_fn, "[Douyin] Auto-fetching cookies from douyin.com...")
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(headless=True)
                context = browser.new_context(user_agent=DOUYIN_UA, locale="zh-CN")
                page = context.new_page()
                page.goto("https://www.douyin.com", wait_until="domcontentloaded", timeout=90000)
                page.wait_for_timeout(5000)
                if sample_url and is_douyin_url(sample_url):
                    page.goto(sample_url, wait_until="domcontentloaded", timeout=90000)
                    page.wait_for_timeout(2000)
                cookies = context.cookies()
                browser.close()

            if not cookies:
                raise RuntimeError("No cookies captured from douyin.com")
            write_netscape_cookies(cookies, dest)
            runtime_message(log_fn, f"[Douyin] Auto cookies saved: {dest}")
            return dest
        except Exception as e:
            err = str(e).lower()
            if attempt == 0 and any(x in err for x in ("executable doesn't exist", "browser not found", "chromium")):
                try:
                    install_chromium()
                    continue
                except Exception as install_err:
                    runtime_message(log_fn, f"[Douyin] Chromium install failed: {install_err}")
            runtime_message(log_fn, f"[Douyin] Auto cookie fetch failed: {e}")
            return None
    return None


def ensure_playwright_chromium(log_fn=None):
    if not ensure_pip_package("playwright", "playwright"):
        raise RuntimeError("Could not install playwright")
    from playwright.sync_api import sync_playwright

    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True)
            browser.close()
        return sync_playwright
    except Exception:
        runtime_message(log_fn, "[Douyin] Installing Chromium (first time only)...")
        subprocess.check_call(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        from playwright.sync_api import sync_playwright

        return sync_playwright


def load_netscape_cookies_for_playwright(path: Path) -> list[dict]:
    cookies: list[dict] = []
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        if not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) < 7:
            continue
        domain, _flag, cookie_path, secure, expires, name, value = parts[:7]
        cookie = {
            "name": name,
            "value": value,
            "domain": domain,
            "path": cookie_path or "/",
            "secure": secure.upper() == "TRUE",
        }
        try:
            exp = int(expires)
            if exp > 0:
                cookie["expires"] = exp
        except ValueError:
            pass
        cookies.append(cookie)
    return cookies


def extract_douyin_media_from_payload(payload) -> tuple[str | None, str | None]:
    """Return (title, best_video_url) from Douyin JSON/page payloads."""
    title = None
    urls: list[str] = []

    def walk(obj, depth: int = 0):
        nonlocal title
        if depth > 12:
            return
        if isinstance(obj, dict):
            for key, value in obj.items():
                key_l = str(key).lower()
                if title is None and key_l in {"desc", "title", "description"} and isinstance(value, str) and value.strip():
                    title = value.strip()
                if key_l in {"playaddr", "downloadaddr", "play_addr", "download_addr", "playurl", "play_url"}:
                    if isinstance(value, str) and value.startswith("http"):
                        urls.append(value)
                    elif isinstance(value, dict):
                        for item in value.get("url_list") or value.get("UrlList") or []:
                            if isinstance(item, str) and item.startswith("http"):
                                urls.append(item)
                    elif isinstance(value, list):
                        for item in value:
                            if isinstance(item, str) and item.startswith("http"):
                                urls.append(item)
                            elif isinstance(item, dict) and isinstance(item.get("src"), str):
                                urls.append(item["src"])
                walk(value, depth + 1)
        elif isinstance(obj, list):
            for item in obj:
                walk(item, depth + 1)

    walk(payload)
    best = None
    for candidate in urls:
        if "mime_type=video_mp4" in candidate or candidate.endswith(".mp4") or "video" in candidate:
            best = candidate
            break
    if not best and urls:
        best = urls[0]
    return title, best


def download_file_with_progress(url: str, dest: Path, headers: dict | None = None, progress_cb=None) -> None:
    req = urllib.request.Request(url, headers=headers or {"User-Agent": DOUYIN_UA, "Referer": "https://www.douyin.com/"})
    with urllib.request.urlopen(req, timeout=120) as response:
        total = int(response.headers.get("Content-Length") or 0)
        done = 0
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "wb") as out:
            while True:
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                out.write(chunk)
                done += len(chunk)
                if progress_cb:
                    progress_cb(done, total)


def playwright_fetch_douyin_info(url: str, log_fn=None, headless: bool = True) -> dict:
    """Open Douyin page in Playwright and capture title + playable media URL."""
    sync_playwright = ensure_playwright_chromium(log_fn)
    cookie_path = douyin_cookies_file()
    captured: dict = {"title": None, "media_url": None, "video_id": None}

    match = DOUYIN_VIDEO_RE.search(url)
    if match:
        captured["video_id"] = match.group("id")

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=headless)
        context = browser.new_context(user_agent=DOUYIN_UA, locale="zh-CN")
        if cookie_path:
            try:
                context.add_cookies(load_netscape_cookies_for_playwright(cookie_path))
            except Exception as e:
                runtime_message(log_fn, f"[Douyin] Could not load cookie file into browser: {e}")

        def on_response(response):
            try:
                resp_url = response.url.lower()
                ctype = (response.headers.get("content-type") or "").lower()
                if "application/json" in ctype or "aweme/detail" in resp_url or "aweme/v1" in resp_url:
                    data = response.json()
                    title, media = extract_douyin_media_from_payload(data)
                    if title and not captured["title"]:
                        captured["title"] = title
                    if media and not captured["media_url"]:
                        captured["media_url"] = media
            except Exception:
                pass

        page = context.new_page()
        page.on("response", on_response)
        runtime_message(log_fn, f"[Douyin] Opening page in browser engine: {url}")
        page.goto(url, wait_until="domcontentloaded", timeout=60000)
        page.wait_for_timeout(2500)

        # Try common page-embedded JSON shapes if network interception missed them.
        try:
            embedded = page.evaluate(
                """() => {
                    const picks = [];
                    if (window.__RENDER_DATA__) picks.push(window.__RENDER_DATA__);
                    if (window.__INIT_PROPS__) picks.push(window.__INIT_PROPS__);
                    if (window.RENDER_DATA) picks.push(window.RENDER_DATA);
                    const scripts = [...document.querySelectorAll('script')].map(s => s.textContent || '');
                    for (const text of scripts) {
                        if (text.includes('playAddr') || text.includes('aweme_detail') || text.includes('videoDetail')) {
                            picks.push(text.slice(0, 500000));
                        }
                    }
                    const video = document.querySelector('video');
                    return {
                        picks,
                        videoSrc: video ? (video.currentSrc || video.src || null) : null,
                        title: document.title || null,
                    };
                }"""
            )
            if isinstance(embedded, dict):
                if embedded.get("videoSrc") and not captured["media_url"]:
                    captured["media_url"] = embedded["videoSrc"]
                if embedded.get("title") and not captured["title"]:
                    title = str(embedded["title"]).replace(" - 抖音", "").strip()
                    if title:
                        captured["title"] = title
                for item in embedded.get("picks") or []:
                    if isinstance(item, str):
                        # Best-effort URL scrape from script text.
                        for m in re.findall(r'https://[^"\\\s]+(?:mime_type=video_mp4|\\.mp4)[^"\\\s]*', item):
                            captured["media_url"] = captured["media_url"] or m.replace("\\u002F", "/")
                        continue
                    title, media = extract_douyin_media_from_payload(item)
                    if title and not captured["title"]:
                        captured["title"] = title
                    if media and not captured["media_url"]:
                        captured["media_url"] = media
        except Exception:
            pass

        # One more short wait for late XHR.
        if not captured["media_url"]:
            page.wait_for_timeout(2500)

        # Persist refreshed cookies from this session.
        try:
            write_netscape_cookies(context.cookies(), app_runtime_dir() / DOUYIN_COOKIES_FILENAME)
        except Exception:
            pass
        browser.close()

    if not captured["title"]:
        captured["title"] = f"douyin_{captured.get('video_id') or 'video'}"
    return captured


def download_douyin_via_playwright(url: str, dest_path: Path, log_fn=None, progress_cb=None) -> bool:
    info = playwright_fetch_douyin_info(url, log_fn=log_fn, headless=True)
    media_url = info.get("media_url")
    if not media_url:
        # Visible retry can pass captcha/login walls better.
        runtime_message(log_fn, "[Douyin] Headless media capture failed; retrying with visible browser...")
        info = playwright_fetch_douyin_info(url, log_fn=log_fn, headless=False)
        media_url = info.get("media_url")
    if not media_url:
        raise RuntimeError(
            "Could not capture Douyin media URL. Use 'Login Douyin (Browser)', open the video once, then retry."
        )
    runtime_message(log_fn, "[Douyin] Media URL captured. Downloading...")
    download_file_with_progress(
        media_url,
        dest_path,
        headers={"User-Agent": DOUYIN_UA, "Referer": "https://www.douyin.com/"},
        progress_cb=progress_cb,
    )
    return dest_path.exists() and dest_path.stat().st_size > 0


def interactive_login_douyin_cookies(log_fn=None, sample_url: str | None = None, timeout_sec: int = 240) -> Path | None:
    if not ensure_pip_package("playwright", "playwright"):
        runtime_message(log_fn, "[Douyin] Could not install playwright.")
        return None

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        runtime_message(log_fn, "[Douyin] Playwright is not available.")
        return None

    dest = app_runtime_dir() / DOUYIN_COOKIES_FILENAME
    app_runtime_dir().mkdir(parents=True, exist_ok=True)

    def install_chromium() -> None:
        runtime_message(log_fn, "[Douyin] Installing Chromium (first time only)...")
        subprocess.check_call(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )

    for attempt in range(2):
        try:
            runtime_message(log_fn, "[Douyin] Opening browser for manual login...")
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(headless=False)
                context = browser.new_context(user_agent=DOUYIN_UA, locale="zh-CN")
                page = context.new_page()
                page.goto("https://www.douyin.com", wait_until="domcontentloaded", timeout=90000)
                if sample_url and is_douyin_url(sample_url):
                    page.goto(sample_url, wait_until="domcontentloaded", timeout=90000)
                runtime_message(log_fn, "[Douyin] Please login in opened browser. Waiting for s_v_web_id cookie...")

                deadline = time.time() + timeout_sec
                saved = False
                while time.time() < deadline:
                    cookies = context.cookies()
                    if any(c.get("name") == "s_v_web_id" for c in cookies):
                        write_netscape_cookies(cookies, dest)
                        saved = True
                        break
                    time.sleep(2)

                browser.close()

            if saved:
                runtime_message(log_fn, f"[Douyin] Login cookies saved: {dest}")
                return dest
            runtime_message(log_fn, "[Douyin] Login timeout. Please retry and login faster.")
            return None
        except Exception as e:
            err = str(e).lower()
            if attempt == 0 and any(x in err for x in ("executable doesn't exist", "browser not found", "chromium")):
                try:
                    install_chromium()
                    continue
                except Exception as install_err:
                    runtime_message(log_fn, f"[Douyin] Chromium install failed: {install_err}")
            runtime_message(log_fn, f"[Douyin] Manual login flow failed: {e}")
            return None
    return None


def ffmpeg_binary_name() -> str:
    return "ffmpeg.exe" if sys.platform.startswith("win") else "ffmpeg"


def ffprobe_binary_name() -> str:
    return "ffprobe.exe" if sys.platform.startswith("win") else "ffprobe"


def find_ffmpeg_dir() -> Path | None:
    system_ffmpeg = shutil.which("ffmpeg")
    if system_ffmpeg:
        return Path(system_ffmpeg).resolve().parent

    candidates: list[Path] = []
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidates.extend([Path(meipass), Path(meipass) / "ffmpeg", Path(meipass) / "ffmpeg" / "bin"])

    root_dir = app_root_dir()
    runtime_dir = app_runtime_dir()
    candidates.extend(
        [
            root_dir,
            root_dir / "ffmpeg",
            root_dir / "ffmpeg" / "bin",
            runtime_dir,
            runtime_dir / "ffmpeg",
            runtime_dir / "ffmpeg" / "bin",
        ]
    )

    ffmpeg_name = ffmpeg_binary_name()
    for folder in candidates:
        if (folder / ffmpeg_name).exists():
            return folder
    return None


def download_ffmpeg_windows(log_fn=None) -> Path:
    runtime_root = app_runtime_dir()
    runtime_root.mkdir(parents=True, exist_ok=True)
    ffmpeg_dir = runtime_root / "ffmpeg" / "bin"
    ffmpeg_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="sna-ffmpeg-", dir=str(runtime_root)) as temp_dir:
        temp_path = Path(temp_dir)
        archive_path = temp_path / "ffmpeg.zip"
        extract_path = temp_path / "extract"
        extract_path.mkdir(parents=True, exist_ok=True)

        runtime_message(log_fn, "[Runtime] Downloading FFmpeg for this PC...")
        request = urllib.request.Request(WINDOWS_FFMPEG_URL, headers={"User-Agent": f"{APP_NAME}/1.0"})
        with urllib.request.urlopen(request, timeout=120) as response:
            with open(archive_path, "wb") as target:
                shutil.copyfileobj(response, target)

        runtime_message(log_fn, "[Runtime] Installing FFmpeg...")
        with zipfile.ZipFile(archive_path) as zip_file:
            zip_file.extractall(extract_path)

        ffmpeg_path = next(extract_path.rglob(ffmpeg_binary_name()), None)
        ffprobe_path = next(extract_path.rglob(ffprobe_binary_name()), None)
        if not ffmpeg_path:
            raise RuntimeError("FFmpeg download succeeded, but ffmpeg.exe was not found in the archive.")

        shutil.copy2(ffmpeg_path, ffmpeg_dir / ffmpeg_binary_name())
        if ffprobe_path:
            shutil.copy2(ffprobe_path, ffmpeg_dir / ffprobe_binary_name())

    return ffmpeg_dir


def ensure_ffmpeg(log_fn=None) -> str:
    existing = find_ffmpeg_dir()
    if existing:
        return str(existing)
    if not sys.platform.startswith("win"):
        raise RuntimeError("FFmpeg was not found. Please install FFmpeg and try again.")
    installed_dir = download_ffmpeg_windows(log_fn=log_fn)
    runtime_message(log_fn, f"[Runtime] FFmpeg ready: {installed_dir}")
    return str(installed_dir)


def is_tiktok_url(url: str) -> bool:
    return "tiktok.com" in url.lower()


def is_douyin_url(url: str) -> bool:
    u = url.lower()
    return "douyin.com" in u or "iesdouyin.com" in u


def is_short_video_url(url: str) -> bool:
    return is_tiktok_url(url) or is_douyin_url(url)


def canonical_douyin_video_url(url: str) -> str | None:
    match = DOUYIN_VIDEO_RE.search(url)
    if match:
        return f"https://www.douyin.com/video/{match.group('id')}"
    return None


def resolve_douyin_url(url: str) -> str:
    canonical = canonical_douyin_video_url(url)
    if canonical:
        return canonical
    if not is_douyin_url(url):
        return url
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": DOUYIN_UA, "Referer": "https://www.douyin.com/"},
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            final_url = resp.geturl() or url
        return canonical_douyin_video_url(final_url) or final_url
    except Exception:
        return url


def normalize_input_url(url: str) -> str:
    url = url.strip().rstrip(".,);]")
    if is_douyin_url(url):
        return resolve_douyin_url(url)
    return url


def extract_urls_from_text(text: str) -> list[str]:
    urls = URL_IN_TEXT_RE.findall(text)
    if urls:
        return [normalize_input_url(u.rstrip(".,);]")) for u in urls]
    stripped = text.strip()
    return [normalize_input_url(stripped)] if stripped else []


def safe_filename(s: str, max_len: int = 160) -> str:
    s = (s or "").strip()
    s = re.sub('[<>:\"/\\\\|?*\\n\\r\\t]+', "_", s)
    s = re.sub("\\s+", " ", s).replace(" ", "_")
    return s[:max_len].strip("_") or "video"


def human_bytes(n: float | int | None) -> str:
    if n is None:
        return ""
    n = float(n)
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while n >= 1024 and i < len(units) - 1:
        n /= 1024
        i += 1
    return f"{n:.2f} {units[i]}"


def human_time(sec: int | float | None) -> str:
    if sec is None:
        return ""
    sec = max(0, int(sec))
    m, s = divmod(sec, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h:d}:{m:02d}:{s:02d}"
    return f"{m:d}:{s:02d}"


def detect_site(info: dict, url: str) -> str:
    ek = (info.get("extractor_key") or "").strip()
    if ek:
        return ek
    u = url.lower()
    if "youtube.com" in u or "youtu.be" in u:
        return "YouTube"
    if "facebook.com" in u or "fb.watch" in u:
        return "Facebook"
    if "tiktok.com" in u:
        return "TikTok"
    if is_douyin_url(u):
        return "Douyin"
    return "Other"


def quality_to_format(quality: str) -> str:
    if quality == "1080p":
        return "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best"
    if quality == "720p":
        return "bestvideo[height<=720]+bestaudio/best[height<=720]/best"
    if quality == "480p":
        return "bestvideo[height<=480]+bestaudio/best[height<=480]/best"
    if quality == "Audio best":
        return "bestaudio/best"
    return "bestvideo+bestaudio/best"


def entry_url(entry: dict) -> str:
    return entry.get("url") or entry.get("webpage_url") or entry.get("original_url") or ""


class DownloaderUI(tb.Window):
    def __init__(self):
        super().__init__(
            title="SNA Video Downloader v2 (Channel/Profile Scan + Select)",
            themename="superhero",
            size=(1240, 760),
            resizable=(True, True),
        )
        self.minsize(980, 620)

        self.folder_var = tk.StringVar(value="")
        self.quality_var = tk.StringVar(value="Best")
        self.filename_tpl = tk.StringVar(value="{title}_{id}")
        self.use_cookies = tk.BooleanVar(value=False)
        self.browser_var = tk.StringVar(value="edge")
        self.skip_exists = tk.BooleanVar(value=True)
        self.embed_meta = tk.BooleanVar(value=False)
        self.subs_var = tk.BooleanVar(value=False)
        self.mp4_var = tk.BooleanVar(value=True)
        self.mp3_var = tk.BooleanVar(value=False)
        self.max_videos_var = tk.IntVar(value=50)

        self.jobs: list[dict] = []
        self.stop_event = threading.Event()
        self.paused = False
        self.current_job_index = 0
        self.worker_thread: threading.Thread | None = None
        self.ffmpeg_dir: str | None = None

        self._load_settings()
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        top = tb.Frame(self, padding=12)
        top.pack(fill=X)
        left = tb.Frame(top)
        left.pack(side=LEFT, fill=X, expand=True)
        tb.Label(left, text="SNA Video Downloader Pro", font=("Segoe UI", 18, "bold")).pack(anchor=W)
        tb.Label(
            left,
            text="Scan channel/profile → list videos → select what to download (All/Custom)",
            bootstyle="secondary",
            font=("Segoe UI", 10),
        ).pack(anchor=W, pady=(2, 0))

        right = tb.Frame(top)
        right.pack(side=RIGHT)
        tb.Button(right, text="Theme", bootstyle="outline-light", command=self.toggle_theme).pack(side=LEFT, padx=6)
        tb.Button(right, text="About", bootstyle="outline-info", command=self.show_about).pack(side=LEFT)

        tb.Separator(self).pack(fill=X)

        body = tb.Frame(self, padding=12)
        body.pack(fill=BOTH, expand=True)
        body.columnconfigure(0, weight=1, uniform="col")
        body.columnconfigure(1, weight=2, uniform="col")
        body.rowconfigure(0, weight=1)

        leftp = tb.Frame(body)
        leftp.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        rightp = tb.Frame(body)
        rightp.grid(row=0, column=1, sticky="nsew")

        tabs = tb.Notebook(leftp, bootstyle="primary")
        tabs.pack(fill=BOTH, expand=True)
        tab_input = tb.Frame(tabs, padding=10)
        tab_opts = tb.Frame(tabs, padding=10)
        tabs.add(tab_input, text="Input")
        tabs.add(tab_opts, text="Options")

        self.url_text = tk.Text(tab_input, wrap="word", font=("Consolas", 10), height=10)
        self.url_text.pack(fill=BOTH, expand=True)

        row_btn = tb.Frame(tab_input)
        row_btn.pack(fill=X, pady=(10, 0))
        tb.Button(row_btn, text="Paste", bootstyle="secondary", command=self.paste_urls).pack(side=LEFT, padx=(0, 8))
        tb.Button(row_btn, text="Import .txt", bootstyle="secondary", command=self.import_txt).pack(side=LEFT, padx=(0, 8))
        tb.Button(row_btn, text="Clear", bootstyle="outline-danger", command=self.clear_urls).pack(side=LEFT)
        tb.Button(row_btn, text="Scan", bootstyle="success", command=self.scan_urls).pack(side=RIGHT)
        tb.Label(
            tab_input,
            text="Tip: Paste YouTube/TikTok/Douyin links. Douyin share text and v.douyin.com short links are supported.",
            bootstyle="secondary",
        ).pack(anchor=W, pady=(8, 0))
        self._build_options(tab_opts)

        rightp.rowconfigure(0, weight=3)
        rightp.rowconfigure(1, weight=2)
        rightp.columnconfigure(0, weight=1)

        queue_card = tb.Labelframe(rightp, text="Queue (click ✅/⬜ to select)", padding=10, bootstyle="primary")
        queue_card.grid(row=0, column=0, sticky="nsew")
        cols = ("SEL", "#", "Title", "Site", "Type", "Status", "File")
        self.tree = tb.Treeview(queue_card, columns=cols, show="headings", height=13, bootstyle="info")
        for c in cols:
            self.tree.heading(c, text=c)
        self.tree.column("SEL", width=55, anchor="center")
        self.tree.column("#", width=45, anchor="center")
        self.tree.column("Title", width=320)
        self.tree.column("Site", width=120, anchor="center")
        self.tree.column("Type", width=80, anchor="center")
        self.tree.column("Status", width=180, anchor="center")
        self.tree.column("File", width=300)
        self.tree.pack(fill=BOTH, expand=True)
        self.tree.bind("<Button-1>", self.on_tree_click)

        ctrl = tb.Frame(queue_card)
        ctrl.pack(fill=X, pady=(10, 0))
        tb.Button(ctrl, text="Select All", bootstyle="secondary", command=self.select_all).pack(side=LEFT, padx=(0, 8))
        tb.Button(ctrl, text="Select None", bootstyle="secondary", command=self.select_none).pack(side=LEFT, padx=(0, 8))
        tb.Button(ctrl, text="Invert", bootstyle="secondary", command=self.select_invert).pack(side=LEFT)
        self.btn_start = tb.Button(ctrl, text="Start", bootstyle="success", command=self.start_download)
        self.btn_start.pack(side=LEFT, padx=(18, 8))
        self.btn_pause = tb.Button(ctrl, text="Pause", bootstyle="warning", command=self.pause_download)
        self.btn_pause.pack(side=LEFT, padx=(0, 8))
        self.btn_stop = tb.Button(ctrl, text="Stop", bootstyle="danger", command=self.stop_download)
        self.btn_stop.pack(side=LEFT)
        tb.Button(ctrl, text="Open Folder", bootstyle="secondary", command=self.open_folder).pack(side=RIGHT)

        logs_card = tb.Labelframe(rightp, text="Logs", padding=10, bootstyle="secondary")
        logs_card.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        logs_card.rowconfigure(0, weight=1)
        logs_card.columnconfigure(0, weight=1)
        self.log = tk.Text(logs_card, state="disabled", wrap="word", height=8, font=("Consolas", 10))
        self.log.grid(row=0, column=0, sticky="nsew")
        scroll = tb.Scrollbar(logs_card, command=self.log.yview, bootstyle="round")
        scroll.grid(row=0, column=1, sticky="ns")
        self.log.configure(yscrollcommand=scroll.set)

        status = tb.Frame(self, padding=(12, 10))
        status.pack(fill=X, side=BOTTOM)
        self.status_var = tk.StringVar(value="Ready")
        tb.Label(status, textvariable=self.status_var, bootstyle="secondary").pack(side=LEFT)
        self.progress = tb.Progressbar(status, mode="determinate", length=340, bootstyle="success-striped")
        self.progress.pack(side=RIGHT)
        self.progress["value"] = 0

    def _build_options(self, parent):
        r1 = tb.Frame(parent)
        r1.pack(fill=X)
        tb.Label(r1, text="Save to", width=12).pack(side=LEFT)
        tb.Entry(r1, textvariable=self.folder_var).pack(side=LEFT, fill=X, expand=True, padx=8)
        tb.Button(r1, text="Browse", bootstyle="secondary", command=self.browse_folder).pack(side=LEFT)

        r2 = tb.Frame(parent)
        r2.pack(fill=X, pady=(12, 0))
        tb.Checkbutton(r2, text="MP4", variable=self.mp4_var, bootstyle="round-toggle").pack(side=LEFT, padx=(0, 10))
        tb.Checkbutton(r2, text="MP3", variable=self.mp3_var, bootstyle="round-toggle").pack(side=LEFT, padx=(0, 20))
        tb.Label(r2, text="Quality").pack(side=LEFT, padx=(0, 8))
        tb.Combobox(
            r2,
            textvariable=self.quality_var,
            values=["Best", "1080p", "720p", "480p", "Audio best"],
            state="readonly",
            width=14,
        ).pack(side=LEFT)

        r3 = tb.Frame(parent)
        r3.pack(fill=X, pady=(12, 0))
        tb.Label(r3, text="Filename", width=12).pack(side=LEFT)
        tb.Entry(r3, textvariable=self.filename_tpl).pack(side=LEFT, fill=X, expand=True, padx=8)
        tb.Button(r3, text="?", bootstyle="outline-info", width=3, command=self.show_filename_help).pack(side=LEFT)

        r4 = tb.Frame(parent)
        r4.pack(fill=X, pady=(12, 0))
        tb.Checkbutton(r4, text="Skip if exists", variable=self.skip_exists, bootstyle="round-toggle").pack(side=LEFT, padx=(0, 10))
        tb.Checkbutton(r4, text="Download subtitles", variable=self.subs_var, bootstyle="round-toggle").pack(side=LEFT, padx=(0, 10))
        tb.Checkbutton(r4, text="Embed metadata", variable=self.embed_meta, bootstyle="round-toggle").pack(side=LEFT, padx=(0, 10))
        tb.Checkbutton(
            r4,
            text="Use browser cookies",
            variable=self.use_cookies,
            bootstyle="round-toggle",
            command=self._cookies_toggle_changed,
        ).pack(side=LEFT, padx=(0, 10))
        self.browser_combo = tb.Combobox(
            r4,
            textvariable=self.browser_var,
            values=["edge", "chrome", "firefox", "brave", "opera"],
            state="readonly",
            width=10,
        )
        self.browser_combo.pack(side=LEFT)
        self._cookies_toggle_changed()

        r_douyin = tb.Frame(parent)
        r_douyin.pack(fill=X, pady=(10, 0))
        tb.Button(
            r_douyin,
            text="Login Douyin (Browser)",
            bootstyle="success",
            command=self.login_douyin_in_browser,
        ).pack(side=LEFT)
        tb.Button(
            r_douyin,
            text="Auto Get Douyin Cookies",
            bootstyle="warning",
            command=self.auto_get_douyin_cookies,
        ).pack(side=LEFT, padx=(8, 0))
        tb.Button(
            r_douyin,
            text="Import Douyin Cookies",
            bootstyle="outline-warning",
            command=self.import_douyin_cookies,
        ).pack(side=LEFT, padx=(8, 0))
        tb.Button(
            r_douyin,
            text="Open .runtime",
            bootstyle="outline-secondary",
            command=self.open_runtime_folder,
        ).pack(side=LEFT, padx=(8, 0))

        r5 = tb.Frame(parent)
        r5.pack(fill=X, pady=(16, 0))
        tb.Label(r5, text="Max videos (channel/profile)", width=22).pack(side=LEFT)
        tb.Spinbox(r5, from_=1, to=9999, textvariable=self.max_videos_var, width=10).pack(side=LEFT)
        tb.Label(
            parent,
            text="Scan will expand playlists/channels/profiles into videos. Use Max videos to limit.",
            bootstyle="secondary",
        ).pack(anchor=W, pady=(10, 0))
        tb.Label(
            parent,
            text="Douyin tip: Scan queues the video even when yt-dlp fails; Start uses browser download.",
            bootstyle="secondary",
        ).pack(anchor=W, pady=(6, 0))

    def _ui(self, fn):
        self.after(0, fn)

    def log_write(self, msg: str):
        self.log.configure(state="normal")
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def set_status(self, msg: str, overall_progress: int | None = None):
        self.status_var.set(msg)
        if overall_progress is not None:
            self.progress["value"] = max(0, min(100, overall_progress))

    def toggle_theme(self):
        current = self.style.theme.name
        if current in ("superhero", "cyborg", "darkly", "vapor"):
            self.style.theme_use("flatly")
        else:
            self.style.theme_use("superhero")

    def show_about(self):
        total = len(self.jobs)
        selected = sum(1 for j in self.jobs if j.get("selected"))
        Messagebox.show_info(
            f"SNA Downloader v2\n\nQueue: {total} item(s)\nSelected: {selected}\n\n"
            "Paste channel/profile/playlist links (YouTube/TikTok) or Douyin video/share links → Scan → Select → Start",
            title="About",
        )

    def show_filename_help(self):
        Messagebox.show_info(
            "Filename template supports:\n  {title}  {id}  {uploader}  {date}\n\nExample:\n  {title}_{id}\n",
            title="Filename help",
        )

    def _cookies_toggle_changed(self):
        if self.use_cookies.get():
            self.browser_combo.configure(state="readonly")
        else:
            self.browser_combo.configure(state="disabled")

    def select_all(self):
        for j in self.jobs:
            j["selected"] = True
        self._refresh_sel_column()
        self.log_write("Selected: ALL")

    def select_none(self):
        for j in self.jobs:
            j["selected"] = False
        self._refresh_sel_column()
        self.log_write("Selected: NONE")

    def select_invert(self):
        for j in self.jobs:
            j["selected"] = not j.get("selected", True)
        self._refresh_sel_column()
        self.log_write("Selected: INVERT")

    def _refresh_sel_column(self):
        for j in self.jobs:
            row = j["row_id"]
            vals = list(self.tree.item(row, "values"))
            vals[0] = "✅" if j.get("selected") else "⬜"
            self.tree.item(row, values=vals)

    def on_tree_click(self, event):
        region = self.tree.identify("region", event.x, event.y)
        if region != "cell":
            return
        col = self.tree.identify_column(event.x)
        if col != "#1":
            return
        row_id = self.tree.identify_row(event.y)
        if not row_id:
            return
        for j in self.jobs:
            if j["row_id"] == row_id:
                j["selected"] = not j.get("selected", True)
                vals = list(self.tree.item(row_id, "values"))
                vals[0] = "✅" if j["selected"] else "⬜"
                self.tree.item(row_id, values=vals)
                break

    def browse_folder(self):
        folder = filedialog.askdirectory(initialdir=self.folder_var.get().strip() or default_save_folder())
        if folder:
            self.folder_var.set(folder)
            os.makedirs(folder, exist_ok=True)
            self._save_settings()
            self.log_write(f"Save folder: {folder}")

    def open_folder(self):
        folder = self.folder_var.get().strip()
        if not folder:
            Messagebox.show_info("Choose a save folder first.", title="Open Folder")
            return
        try:
            if sys.platform.startswith("win"):
                os.startfile(folder)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception:
            pass

    def paste_urls(self):
        try:
            txt = self.clipboard_get().strip()
            if txt:
                self.url_text.insert("end", txt + "\n")
        except tk.TclError:
            Messagebox.show_warning("Clipboard is empty.", title="Clipboard")

    def import_txt(self):
        path = filedialog.askopenfilename(filetypes=[("Text file", "*.txt")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                self.url_text.insert("end", f.read().strip() + "\n")
            self.log_write(f"Imported URLs: {path}")
        except Exception as e:
            Messagebox.show_error(str(e), title="Import failed")

    def clear_urls(self):
        self.url_text.delete("1.0", "end")
        self.log_write("Cleared URL list.")

    def _get_urls(self) -> list[str]:
        urls: list[str] = []
        seen: set[str] = set()
        for line in self.url_text.get("1.0", "end").splitlines():
            for url in extract_urls_from_text(line):
                if url and url not in seen:
                    seen.add(url)
                    urls.append(url)
        return urls

    def _douyin_browser_candidates(self) -> list[str]:
        preferred = (self.browser_var.get() or "edge").strip().lower()
        ordered = [preferred] + [b for b in DOUYIN_BROWSER_FALLBACKS if b != preferred]
        available: list[str] = []
        for browser in ordered:
            if is_browser_running(browser):
                self.log_write(f"[Douyin] Skip {browser}: browser is open (cookie file locked).")
                continue
            available.append(browser)
        return available

    def _douyin_cookie_hint(self) -> str:
        cookies_path = app_runtime_dir() / DOUYIN_COOKIES_FILENAME
        return (
            "Douyin needs cookies.\n\n"
            "Click 'Login Douyin (Browser)' in Options (recommended).\n"
            "Then retry scan. You can also use Auto Get / Import cookies.\n"
            "Or import a Netscape cookies .txt file manually.\n\n"
            f"Cookie file path:\n{cookies_path}"
        )

    def login_douyin_in_browser(self):
        def worker():
            result = interactive_login_douyin_cookies(self.log_write)
            if result:
                self._ui(
                    lambda: Messagebox.show_info(
                        f"Douyin login cookies saved.\n\n{result}\n\nYou can Scan again now.",
                        title="Login cookies ready",
                    )
                )
            else:
                self._ui(lambda: Messagebox.show_warning(self._douyin_cookie_hint(), title="Douyin cookies needed"))

        self.log_write("[Douyin] Starting manual login flow...")
        threading.Thread(target=worker, daemon=True).start()

    def auto_get_douyin_cookies(self):
        def worker():
            result = auto_fetch_douyin_cookies(self.log_write)
            if result:
                self._ui(
                    lambda: Messagebox.show_info(
                        f"Douyin cookies saved.\n\n{result}\n\nYou can Scan again now.",
                        title="Cookies ready",
                    )
                )
            else:
                self._ui(lambda: Messagebox.show_warning(self._douyin_cookie_hint(), title="Douyin cookies needed"))

        self.log_write("[Douyin] Starting auto cookie fetch...")
        threading.Thread(target=worker, daemon=True).start()

    def import_douyin_cookies(self):
        path = filedialog.askopenfilename(
            title="Import Douyin cookies (Netscape .txt format)",
            filetypes=[("Cookies text", "*.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        dest = app_runtime_dir() / DOUYIN_COOKIES_FILENAME
        app_runtime_dir().mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
        self.log_write(f"[Douyin] Cookies imported: {dest}")
        Messagebox.show_info(
            f"Douyin cookies saved.\n\n{dest}\n\nYou can Scan again now.",
            title="Cookies imported",
        )

    def open_runtime_folder(self):
        folder = str(app_runtime_dir())
        os.makedirs(folder, exist_ok=True)
        try:
            if sys.platform.startswith("win"):
                os.startfile(folder)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception as e:
            Messagebox.show_error(str(e), title="Open folder failed")

    def _ytdl_common_opts(self) -> dict:
        return {
            "quiet": True,
            "no_warnings": True,
            "logger": _YtdlQuietLogger(),
        }

    def _apply_platform_opts(self, ydl_opts: dict, url: str, browser: str | None = None) -> None:
        if is_douyin_url(url):
            ydl_opts.setdefault("http_headers", {})
            ydl_opts["http_headers"].update(
                {
                    "User-Agent": DOUYIN_UA,
                    "Referer": "https://www.douyin.com/",
                }
            )
            cookie_file = douyin_cookies_file()
            if cookie_file:
                ydl_opts["cookiefile"] = str(cookie_file)
                ydl_opts.pop("cookiesfrombrowser", None)
            else:
                ydl_opts.pop("cookiefile", None)
                ydl_opts["cookiesfrombrowser"] = (browser or self.browser_var.get() or "edge",)
        elif self.use_cookies.get():
            ydl_opts["cookiesfrombrowser"] = (self.browser_var.get(),)

    def _run_ytdl(self, opts: dict, url: str, download: bool):
        with contextlib.redirect_stderr(io.StringIO()):
            with yt_dlp.YoutubeDL(opts) as ydl:
                if download:
                    return ydl.download([url])
                return ydl.extract_info(url, download=False)

    def _ytdl_run(self, url: str, ydl_opts: dict, download: bool = False):
        ydl_opts = {**self._ytdl_common_opts(), **ydl_opts}
        if is_douyin_url(url):
            # yt-dlp Douyin extractor is currently broken even with valid cookies.
            # Keep one quiet attempt; callers should fall back to Playwright.
            cookie_file = douyin_cookies_file()
            if cookie_file:
                opts = dict(ydl_opts)
                self._apply_platform_opts(opts, url)
                self.log_write(f"[Douyin] Trying yt-dlp with cookie file: {cookie_file}")
                try:
                    return self._run_ytdl(opts, url, download)
                except Exception as e:
                    if is_recoverable_douyin_error(str(e)):
                        self.log_write(
                            "[Douyin] yt-dlp cookie method failed (known Douyin site issue). "
                            "Switching to browser download..."
                        )
                        raise
                    raise
            self.log_write("[Douyin] No cookie file for yt-dlp; using browser download path.")
            raise RuntimeError("Douyin requires browser download fallback")

        opts = dict(ydl_opts)
        self._apply_platform_opts(opts, url)
        return self._run_ytdl(opts, url, download)

    def _ydl_base_opts(self):
        return {
            **self._ytdl_common_opts(),
            "noplaylist": False,
            "skip_download": True,
            "extract_flat": "in_playlist",
            "playlistend": int(self.max_videos_var.get() or 50),
        }

    def scan_urls(self):
        if self.worker_thread and self.worker_thread.is_alive():
            Messagebox.show_warning("Downloading is running. Stop first.", title="Busy")
            return
        urls = self._get_urls()
        if not urls:
            Messagebox.show_warning("Please paste URLs first.", title="Scan")
            return
        if not self.mp4_var.get() and not self.mp3_var.get():
            Messagebox.show_warning("Select MP4 and/or MP3 in Options.", title="Format")
            return
        folder = self.ensure_save_folder()
        self.log_write(f"Save folder: {folder}")

        self.stop_event.clear()
        self.jobs = []
        self.current_job_index = 0
        self.tree.delete(*self.tree.get_children())
        self.set_status("Scanning…", overall_progress=0)
        self.log_write(f"Scanning {len(urls)} link(s)… (max videos each: {self.max_videos_var.get()})")
        if any(is_douyin_url(u) for u in urls):
            self.log_write("[Douyin] Using browser fallback when yt-dlp extractor fails.")

        def scan_worker():
            try:
                for idx, url in enumerate(urls, start=1):
                    if self.stop_event.is_set():
                        break
                    self._scan_one_link(url, folder)
                    self._ui(
                        lambda idx=idx, n=len(urls): self.set_status(
                            f"Scanning {idx}/{n}",
                            overall_progress=int(idx / n * 100),
                        )
                    )
                self._ui(lambda: self.set_status(f"Scan complete. Found {len(self.jobs)} item(s).", overall_progress=0))
                self._ui(lambda: self.log_write(f"Scan finished. Total items: {len(self.jobs)}"))
                self._ui(lambda: Messagebox.show_info(f"Found {len(self.jobs)} video(s) in total.", title="Scan result"))
            except Exception as e:
                self._ui(lambda e=e: self.log_write(f"[Scan Error] {e}"))
                self._ui(lambda e=e: Messagebox.show_warning(str(e), title="Scan failed"))

        threading.Thread(target=scan_worker, daemon=True).start()

    def _format_base_name(self, title: str, vid: str, uploader: str, upload_date: str) -> str:
        base = self.filename_tpl.get().strip() or "{title}_{id}"
        base = base.format(
            title=safe_filename(title),
            id=safe_filename(vid),
            uploader=safe_filename(uploader),
            date=safe_filename(upload_date),
        )
        return safe_filename(base)

    def _scan_douyin_fallback(self, url: str, folder: str) -> int:
        """Add Douyin queue item without depending on broken yt-dlp extractor."""
        title = f"douyin_{DOUYIN_VIDEO_RE.search(url).group('id') if DOUYIN_VIDEO_RE.search(url) else 'video'}"
        media_url = None
        try:
            info = playwright_fetch_douyin_info(url, log_fn=self.log_write, headless=True)
            if info.get("title"):
                title = info["title"]
            media_url = info.get("media_url")
            if not media_url:
                self.log_write("[Douyin] Media not found headless; queueing URL for Start-time capture.")
            else:
                self.log_write("[Douyin] Media URL cached for faster Start download.")
        except Exception as e:
            self.log_write(f"[Douyin] Browser preview failed ({e}); queueing URL for Start-time capture.")

        vid_match = DOUYIN_VIDEO_RE.search(url)
        vid = vid_match.group("id") if vid_match else "id"
        base = self._format_base_name(title, vid, "", "")
        added = 0
        if self.mp4_var.get():
            self._add_job(url, title, "Douyin", "MP4", str(Path(folder) / f"{base}.mp4"), media_url=media_url)
            added += 1
        if self.mp3_var.get():
            self._add_job(url, title, "Douyin", "MP3", str(Path(folder) / f"{base}.mp3"), media_url=media_url)
            added += 1
        self._ui(lambda: self.log_write(f"[Scan] Douyin queued: {title}"))
        return added

    def _scan_one_link(self, url: str, folder: str) -> int:
        url = normalize_input_url(url)
        if is_douyin_url(url):
            self._ui(lambda: self.log_write(f"[Douyin] Resolved: {url}"))
            try:
                opts = self._ydl_base_opts()
                info = self._ytdl_run(url, opts, download=False)
            except Exception as e:
                self.log_write(f"[Douyin] yt-dlp scan failed: {e}")
                return self._scan_douyin_fallback(url, folder)
        else:
            opts = self._ydl_base_opts()
            info = self._ytdl_run(url, opts, download=False)

        entries = info.get("entries")
        if entries:
            added = 0
            site = detect_site(info, url)
            for e in entries:
                if not e:
                    continue
                u = entry_url(e)
                if not u:
                    continue
                if not u.startswith("http"):
                    u = e.get("webpage_url") or u
                title = e.get("title") or "Unknown"
                vid = str(e.get("id") or f"id_{added + 1}")
                uploader = e.get("uploader") or e.get("channel") or info.get("uploader") or ""
                upload_date = e.get("upload_date") or info.get("upload_date") or ""
                base = self._format_base_name(title, vid, uploader, upload_date)
                if self.mp4_var.get():
                    self._add_job(u, title, site, "MP4", str(Path(folder) / f"{base}.mp4"))
                if self.mp3_var.get():
                    self._add_job(u, title, site, "MP3", str(Path(folder) / f"{base}.mp3"))
                added += 1
            self._ui(lambda: self.log_write(f"[Scan] Expanded list: {added} video(s) from: {url}"))
            return added

        title = info.get("title") or "Unknown"
        vid = str(info.get("id") or "id")
        uploader = info.get("uploader") or info.get("channel") or ""
        site = detect_site(info, url)
        base = self._format_base_name(title, vid, uploader, info.get("upload_date") or "")
        added = 0
        if self.mp4_var.get():
            self._add_job(url, title, site, "MP4", str(Path(folder) / f"{base}.mp4"))
            added += 1
        if self.mp3_var.get():
            self._add_job(url, title, site, "MP3", str(Path(folder) / f"{base}.mp3"))
            added += 1
        self._ui(lambda: self.log_write(f"[Scan] Single video: {title}"))
        return added

    def _add_job(self, url: str, title: str, site: str, jobtype: str, filepath: str, media_url: str | None = None):
        def add_row():
            row_id = self.tree.insert(
                "",
                "end",
                values=("✅", len(self.jobs) + 1, title, site, jobtype, "Pending", filepath),
            )
            self.jobs.append(
                {
                    "url": url,
                    "title": title,
                    "site": site,
                    "type": jobtype,
                    "filepath": filepath,
                    "row_id": row_id,
                    "status": "Pending",
                    "done": False,
                    "selected": True,
                    "media_url": media_url,
                }
            )

        self._ui(add_row)

    def start_download(self):
        if self.worker_thread and self.worker_thread.is_alive():
            Messagebox.show_info("Already downloading.", title="Info")
            return
        selected_jobs = [j for j in self.jobs if j.get("selected")]
        if not selected_jobs:
            Messagebox.show_warning("No items selected. Select videos first.", title="Start")
            return

        folder = self.ensure_save_folder()
        self.stop_event.clear()
        self.paused = False

        # Immediate UI feedback (do NOT block UI with ffmpeg/cookie setup).
        self.btn_start.configure(state="disabled")
        self.set_status("Downloading…", overall_progress=0)
        self.log_write(f"Save folder: {folder}")
        self.log_write(f"Download started. Selected: {len(selected_jobs)}/{len(self.jobs)}")
        for job in selected_jobs:
            if not job.get("done"):
                self._update_job_status(job, "Queued…")

        self.worker_thread = threading.Thread(target=self._download_worker, daemon=True)
        self.worker_thread.start()

    def pause_download(self):
        if self.worker_thread and self.worker_thread.is_alive():
            self.paused = True
            self.stop_event.set()
            self.set_status("Pausing…", overall_progress=int(self.progress["value"]))
            self.log_write("Pause requested (will stop current; Start resumes).")

    def stop_download(self):
        if self.worker_thread and self.worker_thread.is_alive():
            self.paused = False
            self.stop_event.set()
            self.set_status("Stopping…", overall_progress=int(self.progress["value"]))
            self.log_write("Stop requested.")

    def _download_worker(self):
        selected = [j for j in self.jobs if j.get("selected")]
        total = len(selected)
        done_count = 0
        try:
            needs_ffmpeg = any(
                (job.get("type") == "MP3") or (job.get("type") == "MP4" and not is_douyin_url(job.get("url", "")))
                for job in selected
            )
            if needs_ffmpeg:
                self._ui(lambda: self.log_write("[Runtime] Preparing FFmpeg..."))
                try:
                    self.ffmpeg_dir = ensure_ffmpeg(log_fn=lambda m: self._ui(lambda msg=m: self.log_write(msg)))
                except Exception as e:
                    self._ui(lambda e=e: self.log_write(f"[Runtime] FFmpeg warning: {e}"))
                    self.ffmpeg_dir = str(find_ffmpeg_dir()) if find_ffmpeg_dir() else None

            for job in selected:
                if self.stop_event.is_set():
                    break
                if job.get("done"):
                    done_count += 1
                    self._update_overall(done_count, total)
                    continue
                if self.skip_exists.get() and os.path.exists(job["filepath"]):
                    self._update_job_status(job, "Skipped (exists)")
                    job["done"] = True
                    done_count += 1
                    self._update_overall(done_count, total)
                    continue

                self._update_job_status(job, "Starting…")
                self._ui(lambda t=job.get("title", ""): self.log_write(f"[Download] Starting: {t}"))
                try:
                    ok = self._download_one(job)
                except Exception as e:
                    ok = False
                    self._ui(lambda e=e: self.log_write(f"[Download Error] {e}"))

                if ok and not self.stop_event.is_set():
                    self._update_job_status(job, "Done")
                    job["done"] = True
                    done_count += 1
                    self._ui(lambda t=job.get("title", ""): self.log_write(f"[Download] Done: {t}"))
                elif self.stop_event.is_set():
                    self._update_job_status(job, "Stopped")
                else:
                    self._update_job_status(job, "Failed")
                    self._ui(lambda t=job.get("title", ""): self.log_write(f"[Download] Failed: {t}"))
                self._update_overall(done_count, total)

            if self.stop_event.is_set():
                if self.paused:
                    self._ui(lambda: self.set_status("Paused.", overall_progress=int(self.progress["value"])))
                else:
                    self._ui(lambda: self.set_status("Stopped.", overall_progress=0))
            else:
                self._ui(lambda: self.set_status("All selected downloads complete.", overall_progress=100))
                self._ui(lambda: self.log_write("All done."))
            self.stop_event.clear()
        except Exception as e:
            self._ui(lambda e=e: self.log_write(f"[Download Error] {e}"))
            self._update_overall(done_count, total)
        finally:
            self._ui(lambda: self.btn_start.configure(state="normal"))

    def _update_overall(self, done: int, total: int):
        pct = int(done / total * 100) if total else 0
        self._ui(lambda: self.set_status(f"Progress: {done}/{total}", overall_progress=pct))

    def _prepare_runtime_dependencies(self, jobs: list[dict]) -> str | None:
        existing_ffmpeg = find_ffmpeg_dir()
        needs_ffmpeg = any(
            (job.get("type") == "MP3") or (job.get("type") == "MP4" and not is_douyin_url(job.get("url", "")))
            for job in jobs
        )
        if not needs_ffmpeg:
            return str(existing_ffmpeg) if existing_ffmpeg else None
        if existing_ffmpeg:
            return str(existing_ffmpeg)
        self.log_write("[Runtime] Checking FFmpeg...")
        return ensure_ffmpeg(log_fn=self.log_write)

    def _download_one(self, job: dict) -> bool:
        url = normalize_input_url(job["url"])
        jobtype = job["type"]
        filepath = job["filepath"]

        # Douyin: skip broken yt-dlp path and download via browser engine directly.
        if is_douyin_url(url):
            self._ui(lambda: self.log_write("[Douyin] Using browser engine download..."))
            self._update_job_status(job, "Opening browser…")
            dest = Path(filepath)

            def progress_cb(done, total):
                if total:
                    pct = int(done * 100 / total)
                    self._update_job_status(job, f"Downloading… {pct}%")
                    self._ui(lambda p=pct: self.set_status(f"Downloading… {p}%", overall_progress=p))
                else:
                    mb = done / (1024 * 1024)
                    self._update_job_status(job, f"Downloading… {mb:.1f} MB")

            media_url = job.get("media_url")
            if media_url:
                self._update_job_status(job, "Downloading…")
                download_file_with_progress(
                    media_url,
                    dest if jobtype == "MP4" else dest.with_suffix(".tmp.mp4"),
                    headers={"User-Agent": DOUYIN_UA, "Referer": "https://www.douyin.com/"},
                    progress_cb=progress_cb,
                )
                temp_mp4 = dest if jobtype == "MP4" else dest.with_suffix(".tmp.mp4")
                if jobtype == "MP4":
                    return temp_mp4.exists() and temp_mp4.stat().st_size > 0
                ffmpeg_dir = self.ffmpeg_dir or (str(find_ffmpeg_dir()) if find_ffmpeg_dir() else None)
                ffmpeg_bin = str(Path(ffmpeg_dir) / ffmpeg_binary_name()) if ffmpeg_dir else "ffmpeg"
                try:
                    self._update_job_status(job, "Converting MP3…")
                    subprocess.check_call(
                        [ffmpeg_bin, "-y", "-i", str(temp_mp4), "-vn", "-acodec", "libmp3lame", "-q:a", "2", str(dest)],
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    )
                    temp_mp4.unlink(missing_ok=True)
                    return dest.exists()
                except Exception as e:
                    self._ui(lambda e=e: self.log_write(f"[Douyin] MP3 convert failed: {e}"))
                    return False

            if jobtype == "MP3":
                temp_mp4 = dest.with_suffix(".tmp.mp4")
                ok = download_douyin_via_playwright(url, temp_mp4, log_fn=lambda m: self._ui(lambda msg=m: self.log_write(msg)), progress_cb=progress_cb)
                if not ok:
                    return False
                ffmpeg_dir = self.ffmpeg_dir or (str(find_ffmpeg_dir()) if find_ffmpeg_dir() else None)
                ffmpeg_bin = str(Path(ffmpeg_dir) / ffmpeg_binary_name()) if ffmpeg_dir else "ffmpeg"
                try:
                    self._update_job_status(job, "Converting MP3…")
                    subprocess.check_call(
                        [ffmpeg_bin, "-y", "-i", str(temp_mp4), "-vn", "-acodec", "libmp3lame", "-q:a", "2", str(dest)],
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    )
                    temp_mp4.unlink(missing_ok=True)
                    return dest.exists()
                except Exception as e:
                    self._ui(lambda e=e: self.log_write(f"[Douyin] MP3 convert failed: {e}"))
                    if temp_mp4.exists() and not dest.exists():
                        temp_mp4.replace(dest)
                    return dest.exists()

            return download_douyin_via_playwright(
                url,
                dest,
                log_fn=lambda m: self._ui(lambda msg=m: self.log_write(msg)),
                progress_cb=progress_cb,
            )

        ydl_opts = {
            **self._ytdl_common_opts(),
            "noplaylist": True,
            "outtmpl": filepath,
            "continuedl": True,
            "retries": 3,
            "fragment_retries": 3,
            "progress_hooks": [lambda d, j=job: self._progress_hook(d, j)],
            "quiet": True,
        }
        if self.ffmpeg_dir:
            ydl_opts["ffmpeg_location"] = self.ffmpeg_dir
        if self.subs_var.get():
            subtitle_langs = ["en", "km", "zh", "zh-Hans", "all"]
            ydl_opts.update(
                {
                    "writesubtitles": True,
                    "writeautomaticsub": True,
                    "subtitleslangs": subtitle_langs,
                    "subtitlesformat": "best",
                }
            )
        if self.embed_meta.get():
            ydl_opts["addmetadata"] = True

        q = self.quality_var.get().strip()
        if jobtype == "MP3":
            ydl_opts["format"] = "bestaudio/best"
            ydl_opts["postprocessors"] = [
                {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}
            ]
        elif is_tiktok_url(url):
            ydl_opts["format"] = "bestvideo[ext=mp4][vcodec^=avc]+bestaudio[ext=m4a]/best[ext=mp4]/best"
            ydl_opts["merge_output_format"] = "mp4"
        else:
            ydl_opts["format"] = quality_to_format(q)
            if q != "Audio best":
                ydl_opts["merge_output_format"] = "mp4"

        result = self._ytdl_run(url, ydl_opts, download=True)
        return result == 0

    def _progress_hook(self, d: dict, job: dict):
        if self.stop_event.is_set():
            raise yt_dlp.utils.DownloadError("Stopped by user")
        status = d.get("status")
        if status == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            done = d.get("downloaded_bytes") or 0
            speed = d.get("speed")
            eta = d.get("eta")
            pct = f"{int(done * 100 / total)}%" if total else ""
            s_speed = f" {human_bytes(speed)}/s" if speed else ""
            s_eta = human_time(eta) if eta is not None else ""
            text = f"Downloading… {pct}{s_speed} ETA {s_eta}".strip()
            self._update_job_status(job, text)
        elif status == "finished":
            self._update_job_status(job, "Processing…")

    def _update_job_status(self, job: dict, status_text: str):
        job["status"] = status_text
        row_id = job["row_id"]

        def ui_update():
            vals = list(self.tree.item(row_id, "values"))
            vals[5] = status_text
            self.tree.item(row_id, values=vals)

        self._ui(ui_update)

    def _load_settings(self) -> None:
        settings = load_settings_dict()
        folder = str(settings.get("save_folder", "")).strip()
        if folder:
            self.folder_var.set(folder)
        else:
            self.folder_var.set(default_save_folder())

        if settings.get("quality"):
            self.quality_var.set(str(settings["quality"]))
        if settings.get("filename_template"):
            self.filename_tpl.set(str(settings["filename_template"]))
        if "use_cookies" in settings:
            self.use_cookies.set(bool(settings["use_cookies"]))
        if settings.get("browser"):
            self.browser_var.set(str(settings["browser"]))
        if "skip_exists" in settings:
            self.skip_exists.set(bool(settings["skip_exists"]))
        if "embed_metadata" in settings:
            self.embed_meta.set(bool(settings["embed_metadata"]))
        if "download_subtitles" in settings:
            self.subs_var.set(bool(settings["download_subtitles"]))
        if "download_mp4" in settings:
            self.mp4_var.set(bool(settings["download_mp4"]))
        if "download_mp3" in settings:
            self.mp3_var.set(bool(settings["download_mp3"]))
        if settings.get("max_videos"):
            try:
                self.max_videos_var.set(int(settings["max_videos"]))
            except (TypeError, ValueError):
                pass

    def _save_settings(self) -> None:
        save_settings_dict(
            {
                "save_folder": self.folder_var.get().strip(),
                "quality": self.quality_var.get().strip(),
                "filename_template": self.filename_tpl.get().strip(),
                "use_cookies": bool(self.use_cookies.get()),
                "browser": self.browser_var.get().strip(),
                "skip_exists": bool(self.skip_exists.get()),
                "embed_metadata": bool(self.embed_meta.get()),
                "download_subtitles": bool(self.subs_var.get()),
                "download_mp4": bool(self.mp4_var.get()),
                "download_mp3": bool(self.mp3_var.get()),
                "max_videos": int(self.max_videos_var.get() or 50),
            }
        )

    def _on_close(self) -> None:
        self._save_settings()
        self.destroy()

    def ensure_save_folder(self) -> str:
        folder = self.folder_var.get().strip()
        if not folder:
            folder = default_save_folder()
            self.folder_var.set(folder)
        os.makedirs(folder, exist_ok=True)
        self._save_settings()
        return folder


if __name__ == "__main__":
    app = DownloaderUI()
    app.mainloop()
